# ⚡ Prompt Optimizer for Lower Token Usage

An AI-powered Streamlit app that rewrites long prompts to use **fewer
tokens** — while preserving intent, constraints, context, and expected
output — using the **Google Gemini API**. Instantly see how many
tokens (and how much money) you saved.

Built for a hackathon problem statement: *"Design and demonstrate an
executable utility that reduces prompt token consumption while
preserving intent, output quality, clarity, and consistency."*

---

## ✨ Features

- 📝 Paste any long AI prompt into a clean, dark-themed UI
- 🚀 One-click optimization powered by Gemini (`gemini-1.5-flash`)
- 📊 Live stats: original tokens, optimized tokens, tokens saved,
  reduction %, estimated GPT-4-equivalent cost saved
- 🎯 5 built-in sample prompts (Coding, SQL, Resume, Email, Customer
  Support) — click to auto-fill the textbox
- 📋 Copy optimized prompt / ⬇️ Download as `.txt` / 🗑️ Clear
- 🛡️ Handles missing API keys, empty prompts, and API/network errors
  gracefully

---

## 📁 Project Structure

```
Prompt-Optimizer/
│
├── app.py              # Streamlit UI (main entry point)
├── optimizer.py         # Gemini API integration & prompt optimization logic
├── token_counter.py     # tiktoken-based token counting & cost estimation
├── requirements.txt     # Python dependencies
├── README.md             # This file
├── .env.example          # Template for your API key
└── assets/                # (optional) logo/images
```

---

## 🔑 How to Get a Gemini API Key

1. Go to [Google AI Studio](https://aistudio.google.com/app/apikey)
2. Sign in with your Google account
3. Click **"Create API Key"**
4. Copy the generated key

---

## 🛠️ Installation

1. **Clone / unzip this project** and open the folder in VS Code.

2. **(Recommended) Create a virtual environment:**

   ```bash
   python -m venv venv
   ```

   Activate it:
   - Windows: `venv\Scripts\activate`
   - macOS/Linux: `source venv/bin/activate`

3. **Install dependencies:**

   ```bash
   pip install -r requirements.txt
   ```

4. **Set up your API key:**

   - Copy `.env.example` to a new file named `.env`
   - Open `.env` and paste your Gemini API key:

     ```
     GEMINI_API_KEY=your_actual_key_here
     ```

---

## ▶️ How to Run

```bash
streamlit run app.py
```

This will open the app automatically in your browser (usually at
`http://localhost:8501`).

---

## 🧪 Usage

1. Click a **sample prompt button** (or paste your own prompt) in the
   "Paste your Prompt" box.
2. Click **🚀 Optimize Prompt**.
3. View the side-by-side comparison and stats:
   - Original vs Optimized prompt text
   - Original Tokens / Optimized Tokens / Tokens Saved
   - Reduction Percentage
   - Estimated Cost Saved (GPT-4-equivalent pricing)
4. Use **Copy**, **Download**, or **Clear** to manage your results.

---

## ⚙️ How It Works

1. **`token_counter.py`** uses `tiktoken` (`cl100k_base` encoding — the
   same one used by GPT-4/3.5-turbo) to count tokens in any text, and
   estimates cost using GPT-4 pricing (~$0.03/1K input, ~$0.06/1K
   output tokens, averaged).
2. **`optimizer.py`** sends your prompt to Gemini with a strict system
   instruction: rewrite it using the minimum tokens possible without
   losing intent, constraints, context, or expected output.
3. **`app.py`** ties it all together into a polished Streamlit UI,
   computing before/after statistics and rendering them with metrics,
   progress bars, badges, and export options.

---

## 🩹 Troubleshooting

| Problem | Solution |
|---|---|
| `Gemini API key not found` | Make sure you created a `.env` file (not just `.env.example`) with `GEMINI_API_KEY=...` |
| `ModuleNotFoundError` | Run `pip install -r requirements.txt` again inside your active virtual environment |
| API/network errors | Check your internet connection and confirm your API key is valid and has quota remaining |
| App won't start | Ensure you're running `streamlit run app.py` from inside the `Prompt-Optimizer` folder |

---

## 🏆 Tech Stack

- **Python 3.9+**
- **Streamlit** — UI framework
- **Google Gemini API** (`google-generativeai`) — prompt optimization
- **tiktoken** — token counting
- **python-dotenv** — environment variable management

---

Built with ⚡ for a 3-hour hackathon.
